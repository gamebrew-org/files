Title: Vulcano 1k
Platform: Atari800 64k min. PAL/NTSC 
Controls: Joystick
Author: Karolj Nadj
eMail: karolj_nadj@web.de
Format: ATR (for Emulator users), XEX (=executable loadable via any DOS).

"Out of sudden the vulcano near to your hometown errupts and throws his pieces towards your city... now your mission is to rescue as many man as you can with your ambulance. hurry to pick them up and bring them back but becarefull not to hit any of the burning stones. you can cover below the skyscrapers but they will not last forever!

Start game by hitting start..."


Features:

- Colourful gfx (background has 16 different colours alone done)
- more than 10 levels
- Sound

