The Sorcerer (Commodore C64/128)

WinVice/CCS64/HOXS64 C64 users:
Loading: 

WinVice: (File, Autostart disk/tape image) open Sorcerer.prg. The game will 
	  automatically load and then run.

CCS64:   Select from the menu, load disk image/tape image and chose SORCERER.PRG

Hoxs64: Autostart programname, SORCERER.PRG

Or convert to a real Commodore C64/C128 on a tape or disk (It is entirely up to
you of course)

The game:

You are the Sorcerer practicing your own spells by making objects appear. You
want to make those objects disappear and the only way to do this is by touching
the object. Each of the following objects will reward you points, which are as
follows:

* Wand = 10 points
* Book = 20 points
* Ring = 30 points
* Key  = 50 points

You have a limited number of objects to collect on each level. 

Obstacles:

You are practicing your spells inside a cave full of bats. Unfortunately those
bats don't like you very much. So they are ready to hunt you down. You must avoid
those bats at all costs, but if you hit one. You will be transported to the start
of the cave. If you are hit 3 times, then you're doomed forever.

This game is only a preview of a full game planned for 2008 (With exactly the same
name) and will contain more than one screen. Probably an ability for the player
to fire at the enemies and also a better presentation. 

We hope you will enjoy playing this game and look forward to more from:

http://www.redesign.sk/tnd64 
THE NEW DIMENSION!

Programming: Richard Bayliss and Marauder Inc.
Graphics: Wayne Womersley
Music: Richard Bayliss

Copyright (C)2007 The New Dimension