HOLIDAYS IN AMSTERDAM

      by Rafal
      
A game for ZX Spectrum 


About the game
--------------
Amsterdam. The city famous for channels, tulips, bicycles, coffeeshops and Red Lights District.
The place where you are going to spend your holidays. And you are going to have an active life
there.

You start at the entrance to your hotel, ready to enjoy your time. Across the street you can see
some places to visit. So don't wait too long and rush for fun. Just be careful about all these
bicycle riders around here

The gameplay
------------
	In order to visit a  fun place you need to go up through the proper door. It satisfies your sexual 
drive or need to have a smoke. Of course it's not free. You must be prepared to pay. As time passes,
you may need to satisfy your needs again.
	You can't have fun all the time, sometimes you need to rest. You may visit your hotel to restore
your vital energy by going down from any place near the hotel.
	When you need money, you should go to the bank by going down from any place nearby.
	People in Amsterdam generally travel by bikes. Unused cars stand parked at the pavement making it
impossible to walk there. You must manouever your way amongst the bikers. Be careful not to be hit 
by the bike, because it ends effectively your holidays.

Controls
--------
You control the game with Kempston Joystick. To start the game or skip game over screen press fire.

The game played no Zx Spectrum 128K has music, which lacks on Zx Spectrum 48K.

How long are you able to survive in Amsterdam?

