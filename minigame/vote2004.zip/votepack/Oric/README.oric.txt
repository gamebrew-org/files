Oric Atmos


All the games are provided as tape images (.tap files), in the Games/
directory.  If you use Euphoric, you can alternatively use the AllInOne
disk image, which boots on a menu allowing you to access all the games.


Windows

  The recommended emulator is Euphoric,

    http://oric.free.fr/EMULATORS/Euphoric.zip

  Unpack it to a directory (recommended: \Program Files, an
  Euphoric subdirectory will be created), then install it by
  double-clicking the setup.js script (in \Program Files\Euphoric
  if you followed the advice above).
  Tape images and disk images can then be loaded by double-clicking
  them from Windows. Exit Euphoric with F10, or reboot the disk with F6.

  Warning: Euphoric directly accesses hardware. Some antivirus software
  don't like that and will prevent it to run : in such a case, you have
  to desactivate the hardware access control of the antivirus software.

Unix

  The recommend emulator is xeuphoric,

    http://www.teaser.fr/~amajorel/xeuphoric/xeuphoric-0.18.2.tar.gz


MacOS

  The recommended emulator is Oric,

    http://emulation.net/oric/

  Unpack it to a directory, then start Oric. Select File -> Open
  Tape... in the menu, and select the game. Type CLOAD"".

Amiga

  The recommended emulator is AmOric,

    http://oric.free.fr/EMULATORS/Amoric.lha
