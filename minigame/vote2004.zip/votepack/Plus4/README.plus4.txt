Commodore Plus/4


The games are available as PRG files, which is the native Plus/4
format.


Windows

  The recommended emulator is YAPE,

    http://yape.plus4.net/

  Unzip and start yape.exe. Select File -> Load PRG in the menu, and
  select a game. Type RUN<enter> to start the game.


Unix

  Try YAPE,

    http://yape.plus4.net/


MacOS

  Try Minus4j the java emulator,

    http://minus4.plus4.net/

  You'll have put the minigame prgs in the same directory as the
  emulator, and edit the Minus4.htm file to load the game files. Open
  Minus4.htm in a java capable web browser and it should start the
  game.


Amiga

  Try Flamingo or CP4,

    http://wuarchive.wustl.edu/~aminet/misc/emu/flamingo.lha
    http://wuarchive.wustl.edu/~aminet/misc/emu/cp4.lha

  Neither Flamingo nor CP4 comes with a ROM image. Grab one from YAPE
  above, and check the forum.
