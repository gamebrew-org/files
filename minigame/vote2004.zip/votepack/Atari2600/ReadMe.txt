===========================================
Master Mind deluxe for the Atari 2600
===========================================

You have to guess the colour and position of Five hidden pegs arranged by the computer
The pegs are chosen from eight colours and may be repeated giving 32768 possibel codes
The computer gives hints with black and white pegs.

Each black peg means, that one of the five guesses is of right colour and at right position
Each white peg means, that a guessed colour was right but in the wrong position.

Using all the earlier hints you must try to guess the correct order and colour of the hidden pegs

Scoring is based on your guesses.
Each guess you take increases the computers score and decreases your score
