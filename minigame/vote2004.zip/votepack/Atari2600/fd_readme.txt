                    FALL DOWN
                     2 6 0 0
                    ---------
                       --- 


About
=====
Fall Down pits the ever-opposed forces of RED and BLUE*
against each other in an ultimate battle to capture
scrolling platforms!

The first player to fall past a platform captures it and
scores a point.  Taking time to collect power-ups can
give some advantage, but taking too long only results in
death at the top of the screen.  Watch out, because the
platforms slowly accelerate...

Fall Down includes both two-player and single-player
modes against a highly effective AI.

*BLUE couldn't make it for the PAL version, but his
side-kick BLUEISH GREEN was more than ready to take
up the fight!




Game Modes
==========
Pressing select on the title screen changes the game
mode.  In order, these are:

Human vs. AI
Human vs. AI, pass-by mode (arrows)
Human vs. AI, invisibility mode (the eye)
Single player
Human vs. Human
Human vs. Human, pass-by mode
Human vs. Human, invisibility mode

In pass-by mode the players don't bounce off each other
as in the default mode.  In invisibility mode the
background alternates colors, making one of the players
invisible.




In-Game Controls
================
                        Jump*

                          ^
                          |
            Move Left  <--O-->  Move Right
                          |
                          v

                         ---

Fire - Use power-ups.

Reset - Return to the title screen.

Select - Pause the game.

B&W/Color - Pause the game**.

Difficulty Switches -  Independently control whether
players wrap around (amateur) or bounce off (pro) the
edge of the screen.  Use these for handicap.

* Jumps are proportional; tapping up lightly results
  in a short jump, holding up jumps much higher.

** This feature is intended for the 7800, which
  replaced the B&W/Color switch with a pause button.
  2600 owners will need to flip the switch twice.



The Power-up System
===================
Occassionally you can collect power-ups, which are then
displayed under your score.  Pressing fire will use all
the power-ups you've collected, but the effects vary
based on how many you have:

1 gives a short speed boost.
2 digs a hole in the platform beneath you.
3 gives a long speed boost.
4 swaps places with the other player in 2-player mode,
  or teleports to the bottom of the screen in 1-player
  mode.



Contact the Author
==================
Fall Down is copyright � 2004 by Aaron Curtis
email:  aaron@mobilegamelab.com