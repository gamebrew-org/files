Atari 2600

The games are in .bin format. Atari 2600 emulators are available for a wide
variety of platforms, and it's pretty straightforward to run all the games.
For games using Paddle controllers you may need to configure the emulator
(generally the mouse is used to simulate the paddle).


Windows:

  The recommended emulator is z26 for Windows.  You can download it here:

	http://www.whimsey.com/z26/z26.html

  Once you unzip the files into a directory, you can then place the various
  .bin files into the same directory.  You will also want to make sure the
  SDL.DLL directory is in the same directory as the z26 executable.  Then
  simply run z26 as follows:
	
	z26 game.bin 

  Including the .bin extension is optional.  You can run SCSIcide as follows:

	z26 -m0 scsicide
  
  Many games require you to press the equivalent of RESET in order to start
  the game.  In z26, this is accomplished by pressing F1.  F2 is the Game
  Select switch.

  
DOS:

  The recommended emulator is the DOS version of z26:
  
	http://www.whimsey.com/z26/z26.html
  
  Running games with the DOS version of z26 is similar to the Windows version.
  

Macintosh:

  The best Macintosh 2600 emulator right now is Stella 1.2.  It's not as up
  to date as the Windows version of Stella (or z26), but it's the only viable
  Mac emulator at present. Stella is carbonized for OS X.
  
	http://emulation.net/atari2600/
 
 
Linux:

  The latest version of Stella, 1.3, is available for Linux and can be
  downloaded here:
  
  http://sourceforge.net/project/showfiles.php?group_id=41847&release_id=86255
  

  
