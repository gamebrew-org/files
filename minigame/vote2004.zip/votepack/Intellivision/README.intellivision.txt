Intellivision


Windows

The recommended emulator is jzintv.  A link is provided on the minigame
home page; this includes a .bat file to install the emulator and run the
game.

To run, double click "go.bat:".

Unix

	?

MacOS

	?

Amiga

	?
