Nintendo Entertainment System


The games are stored as .nes cartridges.


Windows

  The recommended emulator is Nestopia,

    http://sourceforge.net/projects/nestopia/

  Unpack it to a directory, then start Nestopia.exe. Select File ->
  Open ROM... in the menu. Double click on a game to start it.

  You might also try FCE Ultra.


Unix

  Try iNES,

    http://fms.komkon.org/iNES/


MacOS

  The recommended emulator is iNES,

    http://emulation.net/nintendo/


Amiga

  The recommended emulator is DarkNESs,

    http://www.mts.net/~fabsced/emu.html


