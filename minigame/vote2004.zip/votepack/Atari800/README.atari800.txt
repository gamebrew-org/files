Atari 800

If you're looking for the Select and Start keys, try F3 and F4 in the
emulator.
 
 
Windows
 
  The recommended emulator is Atari800Win:
 
        http://atari800.sourceforge.net/
 
  Unpack it to a directory and start the program. Select
  File -> Autoboot Image or File -> Load Executable to start
  a game.
 
  The ROM files are available from the Downloads page, or by going to
 
        http://sourceforge.net/project/showfiles.php?group_id=40606
 

Unix

  The recommended emulator is Atari800:

	http://atari800.sourceforge.net


MacOS

  The recommended emulator is Atari800:

	http://www.serve.com/derekl/atari/atari_emu.html


Amiga

  The recommended emulator is Atari800:

	http://atari800.atari.org

