Sinclair ZX Spectrum/Spectrum 128k

All the games - for both Spectrum 48k and 128k - are in the tape file
"spectrum.tap". Just load the first program. That will identify the
Spectrum model you are using, and will allow you to choose the game to
load. When you want to try a new game, restart from the menu. In some
emulators it is sufficient to re-select the tape file, in others it is
simplier to re-launch the emulator.

All games work on the Spectrum 128k, so please emulate that. Some require to
have that Spectrum model to run in 48k mode. The menu system will help you in
that.



Windows

  The first recommended emulator is Spectaculator,

    http://www.spectaculator.com/

  However, from version 6, it is shareware. If you can find version 5.x
  somewhere on the web, you can freely use it (or if you have it already
  installed from last year), You can use the one month-trial period for
  newer versions to try the minigames.

  (instructions for version 5.x)
  Simply install it. Once launched, click on Close if a window pops up.
  Select the model (128k) by selecting Control -> Model (or Ctrl-W).
  To open the .tap file, select File -> Open (or CTRL-O) and double-click
  on the .tap file.
  To select a joystick, Tools -> Options (Ctrl-Y), and then Keyboard if
  you want the joystick emulated by the keyboard, or Joystick if you want
  to use a real joystick.


  The second recommended emulator is SPIN

  ftp://ftp.worldofspectrum.org/pub/sinclair/emulators/pc/windows/SPIN041.zip

  Unpack it. Once launched, as a one-time action, click on the second
  button from the right ("Set SPIN options"), select "Tape Files", check
  the first two ckeckboxes ("automatically Load Tapes" and "Automatically
  Start/Stop the Tape") and click on okay.
  To open the .tap file, click on the second button from the left ("Open a
  file").
  To select a joystick, click on the second button from the right ("Set
  SPIN options"), select "Control", and choose the joystick to emulate from
  the   first list, or from the second if you have a real joystick plugged
  in.


Unix

  The recommended emulator is Fuse,

    http://www.srcf.ucam.org/~pak21/spectrum/fuse.html


MacOS

  Try MacSpectacle,

    http://emulation.net/zx/


Amiga

  The recommended emulator is X128,

    http://www.lagernet.clara.co.uk/x128.html

  Unpack the emulator and the rom files in the same directory. If your
  Amiga is slow set frameskip to 2 or more (using X128Prefs) to speed
  things up. After having started the emulator, press F7 to select the
  .TAP iimage and then select "Tape loader". The menu will load, press
  a number to select a game. F4 lets you select joystick type for
  those games that support a joystick. F10 exits the emulation.
