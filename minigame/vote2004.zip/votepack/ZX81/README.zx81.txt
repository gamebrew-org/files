Sinclair ZX-81

README.zx81.txt

The games are stored as .p files, whatever they are.



Windows

  The recommended emulator is EightyOne

    http://www.chuntey.com/eightyone/

  Unpack it to a directory and start EightyOne. Select File -> Open Tape
  in the menu, and select a game to run.


Unix

  Try Z81,

    http://rus.members.beeb.net/z81.html


MacOS

  Try ZX81,

    http://emulation.net/sinclair/


Amiga

  The recommended emulator is Z81,

    http://www.lagernet.clara.co.uk/8bitemu.html

  Start the emulator from CLI/Shell, with the following command:

    xz81 FILENAME.P

  Where FILENAME.P is the name of the game you want to play. If that
  doesn`t work, try the following instead:

    xz81 -w FILENAME.P

  This opens the emulator in a workbench window.
