Commodore C64


All the games are in a single D64 disk image. Most games requires a
joystick plugged into port 2.

Subdestroyer must be run in PAL mode.  In VICE, go to Options->Video Standard
and select PAL-G.


Windows

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack it to a directory and start x64.exe. Select File -> Autostart
  disk/tape image... in the menu. Select the D64 image, then
  doubleclick on a game to start it. If joystick emulation isn't
  enabled by default, enable it in Settings -> Joystick settings.


Unix

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack and compile with ./configure && make install, then start x64.
  Select File -> Autostart disk/tape image... in the menu. Select the
  D64 image, then doubleclick on a game to start it. If joystick
  emulation isn't enabled by default, enable it in Settings ->
  Joystick settings.


MacOS

  The recommended emulator is Power64,

    http://emulation.net/c64/

  Star Power64 then drag and drop the D64 onto the Power64 window.
  Double click on a game name to start it.


Amiga

  The recommended emulator is MagiC64,

    http://wuarchive.wustl.edu/~aminet/misc/emu/MagiC64.lha

  Start Magic64, select sound playback library in the sound config
  menu, then click "d64 images" and select the D64 image. Doubleclick
  a game or press Load+Run to start it. Press Esc followed by Amiga+M
  to return to the menu. On fast Amigas you can slow down the
  emulation by clicking "Graphics" in the menu, and change framerate
  to 1, select "Syncrhronize" and "Limit speed". Dual 1024 and
  Starinvaders don`t work.
