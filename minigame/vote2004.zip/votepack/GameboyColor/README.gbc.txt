Nintendo Gameboy Color


The games are stored as .gbc cartridges.


Windows

  The recommended emulator is No$GMB,

    http://www.work.de/nocash/gmb.htm

  Unpack it to a directory and start GMB.BAT. Select File -> Cartridge
  menu (FileName) in the menu. Double click on a game to start it.


Unix

  The recommended emulator is gnuboy,

    http://gnuboy.unix-fu.org/


MacOS

  The recommended emulator is Virtual Gameboy,

    http://emulation.net/gameboy/

  Unpack it to a directory and start Virtual Gameboy. Doubleclick on a
  game to start it.


Amiga

  Try GBE,

    http://www.amidog.com/emu/gbe/

  It's PPC only.
