This is the votepack for the 2004 Minigame contest.

Please vote on as many games as you can.  Don't worry if you're
unfamiliar with a platform; that's part of the fun, and in some ways
it may make you a better judge of the platform.  I do ask that you actually
play a game before voting for it, and to otherwise be honest in your voting.

The README files for each platform contain emulator info and info about
the games which you may find helpful.  Some emulators -- for the
Intellivision, Enterprise128, MSX, and Oric -- are available on the
minigame homepage.

You may vote using any criterion you want to.  Voting is done via your
account on the minigame homepage,

	http://www.ffd2.com/minigame/

When you are done voting, you MUST 'submit' your votes.  Once submitted,
that's it -- you can only submit once.  When you press the submit button,
you are saying that you played the most recent version of the game, that
these are your final votes and comments, and that you want them to be
counted.

The voting deadline is Monday, November 1st, 2004.  As usual, this
means that I will close things down on Tuesday morning my time, so that
you have the full weekend (plus Monday -- no need to take a laptop plus
minigames to the Halloween party).

Have fun, and thanks for participating in the contest!

-- The Mgt.

The 2004 Minigame Team:

  Richard Wilson: 	Amstrad CPC
  Paolo Ferraris: 	Spectrum, ZX81
  RoboNes:		NES, MSX, Sega Mastersystem, Intellivision
  Maxim:		Sega Mastersystem
  Fabrice Frances:	Oric
  MagerValp:		Plus/4, Atari 800
  Albert Yarusso:	Atari 2600
  Steve Judd:		Commodore 64/VIC-20, Apple ][
  Robin Harbron:	Colecovision

The web hosting (starbase) was provided by the ever-ruling Adrian Gonzalez,
and the BBS was set up by the "for awesome" Mark Seelye.

There are probably many others, who contributed to the functioning of the
contest, who I should acknowledge but have left off here.  You have my
apologies and my thanks!

Great big thumbgs up to the minigame team as always, and thanks to all the
submitters!

