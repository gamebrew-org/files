MSX Computer

The games are stored as .dsk disks.


Windows

  The recommended emulator is no$msx,

    http://www.work.de/nocash/msx.htm 

  Unpack it to a directory, then run no$msx.exe. Press F12 for file list.
  Double click on a game to start it.

  You might also try BlueMSX; a link is provided on the minigame homepage.
  Go to file->disk drive A->Insert and load tetrinet.dsk, then type
  
	bload"game.bin",r


Unix

  Try fmsx,

    http://fms.komkon.org/fMSX/


MacOS

  Try fMSX,

    http://bannister.org/software/fmsx.htm


Amiga

  Try fmsx,

    ftp://ftp.funet.fi/pub/msx/emulator/fmsxamiga.lha


