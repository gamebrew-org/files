Enterprise 128


Windows

The recommended emulator is EP32; a link is provided on the minigame
homepage.

Go to file->select directory for tape files.  Select the directory with
sokoban.com file in it press ok.  In the emulator window type
load"tape:sokoban.com"

Unix

	?

MacOS

	?

Amiga

	?
