blockhead by proppy & tet
(!warning this is a-w.i.p-unfinished-4ko-sms-minigame)

the goal his to turn the martian happy
by shooting monsters of the same colors

proppy@gmail.com
watch www.epitech.net/~euphro_j/sms for update

thanx to omar cornut for SAT tricks, and moral support,
thanx to smspower
greets to maxim for his awesome tools
