Sega Master System

The games are stored as .sms cartridge images.


Windows

  The recommended emulator is Meka,

    http://www.smspower.org/meka/

  Download the latest version of MekaW. Unpack it to a directory, then
  start mekaw.exe. Select MAIN -> Load ROM in the menu. Double click on
  a game to start it. If your computer is horribly slow then try BrSMS,
  which sacrifices precision for speed. It has no website any more, so
  go here for a mirror:

    http://www.zophar.net/sms-gg.html


Unix

  The recommended emulator is Meka,

    http://www.smspower.org/meka/

  which has x86 Unix builds and is as easy to use. Otherwise, look here:

    http://www.zophar.net/unix/sms-gg.html

  for various options.



Mac

  SMS Plus has a recent OS X build,

    http://www.bannister.org/software/emu.htm

  ...else try Master Gear,

    http://fms.komkon.org/MG/


Amiga

  The recommended emulator is AmiMasterGear,

    http://www.arrakis.es/~joanant/amg.html


