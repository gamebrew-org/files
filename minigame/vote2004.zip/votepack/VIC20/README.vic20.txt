Commodore VIC-20


All the games are in a single D64 disk image.  All the games are for the
unexpanded VIC-20, so disable any expansion memory before starting the
games. Some games require a joystick.


Windows

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack it to a directory and start xvic.exe. Select Settings -> VIC
  Settings... in the menu, and then choose "no expansion memory".
  Select File -> Autostart disk/tape image... in the menu. Select the
  D64 image, then doubleclick on a game to start it. If joystick
  emulation isn't enabled by default, enable it in Settings ->
  Joystick settings.

  To enable expansion memory, use Settings -> VIC settings -> Full.  To
  disable expansion memory, use Settings -> VIC settings -> No expansion mem.


Unix

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack and compile with ./configure && make install, then start
  xvic. Select Settings -> VIC Settings... in the menu, and then
  choose "no expansion memory". Select File -> Autostart disk/tape
  image... in the menu. Select the D64 image, then doubleclick on a
  game to start it. If joystick emulation isn't enabled by default,
  enable it in Settings -> Joystick settings.

  To enable expansion memory, use Settings -> VIC settings -> Full.  To
  disable expansion memory, use Settings -> VIC settings -> No expansion mem.


MacOS

  The recommended emulator is Power20,

    http://emulation.net/vic20/

  Start Power20 then drag and drop the D64 onto the Power20 window.
  Double click on a game name to start it.


Amiga

  The recommended emulator is vic-emu,

    http://wuarchive.wustl.edu/~aminet/misc/emu/vicV0.65.lha

  You will also need und64 from Aminet:

    http://wuarchive.wustl.edu/~aminet/misc/emu/und64.lha

  (Or you can download the zipped .PRG files from the competition
  website.) First copy und64 to the C dir of your SYS: partition. Then
  extract the .PRG files from the .D64 file with this CLI/Shell
  command:

    und64 x vic20.d64

  Run the emulator (vic-20). Type LOAD and press return. Select a game
  in the file requester. Type RUN and press return. 
