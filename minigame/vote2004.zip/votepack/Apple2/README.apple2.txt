Apple ][


DOS overview

  Submissions should be on a DOS3.3 disk image.  CATALOG gives a directory.
  To determine filesize, type CATALOG and multiply the number of sectors
  minus one by 256.


Windows

  The recommended emulator is AppleWin

	http://www.tomcharlesworth.pwp.blueyonder.co.uk/ 

  Unpack it to a directory and double-click the APPLEWIN icon.  Select
  the disk drive-1 icon and select the .DSK image.  Select the Apple icon
  to restart the computer, and follow the menu.



Unix / Linux

  Sadly Apple ][ emulator support for Linux is poor.
  I apologize in advance for the convoluted instructions.

  The recommended emulator is YAE:

    http://www.netfront.net:6502

  + Download the source (yae.tar.gz) from above site
  + Unpack ( tar -xzvf yae.tar.gz)
  + Enter the directory ( cd yae-0.6 )
  + Run "./configure"
  + Edit the file "iou.c" and on like 550 change the line
    FILE *printstream=stdout;
      to
    FILE *printstream=NULL;
  + Run "make"
  + If you get a series of errors at the end about X libraries not being
    found you'll have to issue the following by hand:
    
    gcc -I/usr/X11R6/include -g -O2 -DSTDC_HEADERS=1 -DHAVE_FCNTL_H=1
        -DHAVE_SYS_IOCTL_H=1 -DHAVE_SYS_TIME_H=1 -DHAVE_UNISTD_H=1
        -DTIME_WITH_SYS_TIME=1 -DRETSIGTYPE=void -DHAVE_GETTIMEOFDAY=1
        -DHAVE_SELECT=1 -DHAVE_STRDUP=1 -DHAVE_SNPRINTF=1  -o apple2 main.o 
	6502.o x_window.o memory.o mm.o loadrom.o disk2.o gcr.o sound.o vbl.o 
	fonts.o mousetext.o ucron.o keyboard.o paddle.o speed.o iou.o memmap.o 
	screen.o scanline8.o scanline16.o scanline32.o colour.o shm.o mouse.o 
	emutrap.o confile.o  -L/usr/X11R6/lib  -lX11 -lICE -lXext
   
  + After the above, you should have a working executable "apple2".  But
    before it will run you'll need to get roms...
  
    + ftp://ftp.apple.asimov.net/pub/apple_II/emulators/rom_images/apple_iie_rom.zip
      unzip in yae-0.6 directory
    + http://inconnu.isu.edu/~ink/new/xapple2/slot6.rom
      save as "DISK.ROM" in the yae-0.6 directory.
      
  + After all this nonsense, run "./apple2 minigame2003.dsk" where
    minigame2003.dsk points to the test disk image.
  
  
  
  
  "xapple2" is a somewhat better emulator than yae, but it is x86 only and
  only runs on 256 color displays.  You can try it out here, and use "F1"
  to select a disk image once it is running.
    + Download from http://packages.debian.org/unstable/otherosfs/xapple2.html
  
  
  You might also try KEGS.


MacOS/OSX

  The recommended emulator is Catakig.  Check out

  	http://emulation.net/apple2/

  for emulator and ROM images.


Amiga

  The recommended emulator is Apple2000e:

	http://www.aminet.org/misc/emu/Apple2000e.lha
