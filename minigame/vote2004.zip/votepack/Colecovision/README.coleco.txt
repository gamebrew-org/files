
ColecoVision


The games are stored as .rom images.  For more emulator and tech info on
ColecoVision, visit Daniel Bienvenu's site: http://www.geocities.com/newcoleco/


Windows

The recommended emulator is MESS,
   
   http://www.mess.org/download.html

Binaries for Win32, MacOS, DOS, AmigaPPC, and UNIX source are
available, though only the Win32 version has been tested.

Once the MESS files have been extracted (with directory structure
intact), put coleco.zip in the MESS bios folder.

coleco.zip contains the ColecoVision bios - it is not included
with MESS.  It is fairly easy to find with a google search - here
is one location with it:  http://bioshouse.free.fr/

Start MESS.  The Windows version includes messgui.exe, an easier
to use front-end.  In the systems window on the left, locate and
double click on ColecoVision.  Under the Devices menu you can
mount the minigame .rom files from the votepack.  Under the
Options menu you can configure the Joystick.


Unix

The recommended emulator is MESS,
   
   http://www.mess.org/download.html


MacOS

The recommended emulator is MESS,
   
   http://www.mess.org/download.html


Amiga

Sorry guys, MESS for AmigaPPC, otherwise you're on your own!
