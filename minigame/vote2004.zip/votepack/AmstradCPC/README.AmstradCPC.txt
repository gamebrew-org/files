Amstrad CPC


The games are stored in DSK disk images. Mount the disk image in the
emulator, then type cat<enter> to list its contents.  Type 

	run "gamename"[enter]

 to start the game.


Windows

  The recommended emulator is WinAPE,

    http://winape.emuunlim.com/

  Unpack it to a directory and start WinAPE32.exe. When you are
  presented with a screen containing "F1 - BASIC", press the "1" key
  on the PC's numeric keypad. Select File -> Drive A: ->
  Insert Disk... in the menu. Doubleclick on a game, then type cat and
  run as above to start the game.


Unix

  Try xcpc,

    http://xcpc.emuunlim.com/


MacOS

  The recommended emulator is Arnold,

    http://emulation.net/cpc/

  Unpack it to a directory and start Arnold. Select File -> Open... in
  the menu. Doubleclick on a game, then type can and run as above to
  start the game.


Amiga

  Try emucpc,

    http://wuarchive.wustl.edu/~aminet/misc/emu/emucpc07.lha

  Mermaid reports that it has trouble loading the minigame disk
  images. dsk2cpc might help,

    http://ftp.uni-paderborn.de/aminet/aminet/misc/emu/dsk2cpc10.lha

  Check the forum for updates.

