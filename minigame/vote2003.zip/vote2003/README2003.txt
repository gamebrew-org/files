This is the votepack for the 2003 Minigame contest.

Please vote on as many games as you can.  Don't worry if you're
unfamiliar with a platform; that's part of the fun, and in some ways
it may make you a better judge of the platform.  The README files for
each platform contain emulator info and info about the games which you
may find helpful.  You may vote using any criterion you want to.

Voting is done via your account on the minigame homepage,

	http://www.ffd2.com/minigame/

and is straightforward.  Note that you can edit your votesheet
at any time, but once you submit it it's final.

The voting deadline is October 26th, 2003 (that is, you've got
through Sunday to finish it; I'll close it down on Monday morning
my time).

Have fun, and thanks for participating in the contest!

-- The Mgt.

The 2003 Minigame Team:

  Richard Wilson: 	Amstrad CPC
  Paolo Ferraris: 	Spectrum, ZX81
  RoboNes:		NES, MSX
  Fabrice Frances:	Oric
  MagerValp:		Plus/4, Atari 800
  Albert Yarusso:	Atari 2600
  Steve Judd:		Commodore 64/128/VIC-20, Apple ][

Vince Weaver was an enormous help with the Apple 2, and did the real work of
putting together the final disk image and writing out the YAE instructions.
I also thank Vince, Anthony Kozar, and Sam Ismail for their helpful comments
about the Apple 2.  Over to the NES, I would like to acknowledge Michael
Martin and Memblers (in addition to RoboNes) for their helpful comments on
the NES.

The web hosting (starbase) was provided by the ever-ruling Adrian Gonzalez,
and the BBS was set up by the "for awesome" Mark Seelye.

There are probably many others, who contributed to the functioning of the
contest, who I should acknowledge but have left off here.  You have my
apologies and my thanks!

I could not ask for a finer group of people than the Minigame team; this
contest would not have happened without them.  Thank you all.  I hope to
never do this again. :)

So... play those games, and VOTE!
