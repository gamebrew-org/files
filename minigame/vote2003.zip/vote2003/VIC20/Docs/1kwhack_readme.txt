Welcome to Whack!


Introduction
------------

Whack is a rogue-like
dungeon exploring game
for unexpanded VIC 20.

Written exclusively
for the 2003 MiniGame
Competition, the game
program is only 1024
bytes in size!

Find your way through
the dungeon levels and
bring the Amulet back
to the surface.

Watch out for fierce
guardian Denoms and
other creatures living
in the dungeons.


Dungeon Symbols
---------------

@  You

Use the cursor keys to
move. Move towards a
monster to attack it.
Any items are picked
up when you walk on
them. Press '.' to
skip a turn and wait.


<  Staircase Up
>  Staircase Down

Staircases take you to
other dungeon levels,
down to the Amulet and
back up.


+  Door

Move towards a door to
kick it open. Monsters
don't open doors.


!  Potion

Potions are a fine
mixture of magic and
alcohol. A guaranteed
refreshment of several
hit points.


$  Gold

Gold may have no real
value in the dungeons
but you can always
boast about it to
other adventurers.


Dungeon Creatures
-----------------

b  Brat

Nasty-looking cross-
breed of bat and rat.
A single brat may not
be much of a threat
but better watch your
step if there's a
roomful of them.


G  Gobbol

Troll-like creatures
with huge muscles and
great armament. 


D  Denom

Guardians of the
Amulet, usually only
appear in the lower
dungeon levels. Hard
to kill, sometimes it
is better to run and
not fight. Especially
if you are carrying
the Amulet.


Tips from the Tavern
--------------------

Learn to fight. Only
one monster should be
facing you at a time.

Monsters only breed
in unexplored areas.

Gather some strength
before going down to
the lowest dungeon
levels.


(c)2003 Aleksi Eeben
www.cncd.fi/aeeben
