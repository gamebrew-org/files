Tammerfors


Another 1k (1024-byte)
unexpanded VIC 20 game
written for the 2003
Minigame Competition:

www.ffd2.com/minigame


Use joystick to steer
your car through the
Hameenpuisto park and
all the seasons.

Survive the rush hour.

Reach the next season
checkpoint before the
time runs out.

Bonus and extra time
collected at each
season change.


(c)2003 Aleksi Eeben
www.cncd.fi/aeeben
