Amstrad CPC


The games are stored in DSK disk images. Mount the disk image in the
emulator, then type cat<enter> to list its contents. There should be a
single 1K game file. Type run"gamename"<enter> to start the game.


Windows

  The recommended emulator is CaPriCe32,

	http://caprice32.cybercube.com/

  Unpack it to a directory and start caprice32.exe. Select Disk -> A
  Insert Disk... in the menu. Doubleclick on a game, then type cat and
  run as above to start the game.

  You might also try WinAPE,

	http://winape.emuunlim.com

  (which was written by the sponsor! :).

Unix

  Try xcpc,

    http://xcpc.emuunlim.com/


MacOS

  The recommended emulator is Arnold,

    http://emulation.net/cpc/

  Unpack it to a directory and start Arnold. Select File -> Open... in
  the menu. Doubleclick on a game, then type can and run as above to
  start the game.


OSX

  Try CPC++

    http://emulation.net/cpc/


Amiga

  Try emucpc,

    http://wuarchive.wustl.edu/~aminet/misc/emu/emucpc07.lha

  Mermaid reports that it has trouble loading the minigame disk
  images. dsk2cpc might help,

    http://ftp.uni-paderborn.de/aminet/aminet/misc/emu/dsk2cpc10.lha

  Check the forum for updates.
