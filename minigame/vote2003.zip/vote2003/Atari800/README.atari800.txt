Atari 800


Windows

  The recommended emulator is Atari800Win:

        http://atari800.atari.org
  
  Unpack it to a directory and start the program. Select
  File -> Autoboot Image or File -> Load Executable to start
  a game.
  
  The ROM files are available from the Downloads page, or by going to

        http://sourceforge.net/project/showfiles.php?group_id=40606


Unix

  The recommended emulator is Atari800:

	http://atari800.atari.org


MacOS

  The recommended emulator is Atari800:

	http://www.serve.com/derekl/atari/atari_emu.html


Amiga

  The recommended emulator is Atari800:

	http://atari800.atari.org

