Oric Atmos


All the games are provided as tape images (.tap files), in the Games/
directory.  If you use Euphoric, you can alternatively use the AllInOne
disk image, which boots on a menu allowing you to access all the games.


Windows

  The recommended emulator is Euphoric,

    http://oric.free.fr/EMULATORS/euphoric099q.zip

  Unpack it to a directory (recommended: \Program Files, an
  Euphoric subdirectory will be created), then double-click the
  setup.js script (in \Program Files\Euphoric if you followed
  the advice above). Tape images can then be loaded by double-
  clicking them (this will start Euphoric); same thing for disk
  images. Exit Euphoric with F10, or reboot the disk with F6.

Unix

  Try xeuphoric,

    http://www.teaser.fr/~amajorel/xeuphoric/


MacOS

  The recommended emulator is Oric,

    http://emulation.net/oric/

  Unpack it to a directory, then start Oric. Select File -> Open
  Tape... in the menu, and select the game. Type CLOAD"".

Amiga

  Use AmOric,

    http://wuarchive.wustl.edu/~aminet/misc/emu/AmoricV1_5.lha
