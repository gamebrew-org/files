Sinclair ZX Spectrum/Spectrum 128k

All the games are in the tape file "spectrum.tap". Just load the first
program. That will identify the Spectrum model you are using, and will allow
you to choose the game to load. When you want to try a new game, re-select
the tape file, or relaunch the emulator.
The menu also shows if a particular Spectrum model is needed. I suggest to
always emulate the Spectrum 128k, and switch to the 48k model only for the
game that recommends it.



Windows

  The recommended emulator is Spectaculator,

    http://www.spectaculator.com/

  Simply install it. Once launched, press Close if a window pops up.
  Select the model (48k/128k) by selecting Control -> Model (or Ctrl-W).
  To open the .tap file, select File -> Open (or CTRL-O) and double-click
  on the .tap file.
  To select a joystick, Tools -> Options (Ctrl-Y), and then Keyboard if
  you want the joystick emulated by the keyboard, Joystick if you want to
  use the real thing.


Unix

  The recommended emulator is Fuse,

    http://www.srcf.ucam.org/~pak21/spectrum/fuse.html


MacOS

  Try MacSpectacle,

    http://emulation.net/zx/


Amiga

  The recommended emulator is X128,

    http://www.lagernet.clara.co.uk/x128.html

  Unpack the emulator and the rom files in the same directory. If your
  Amiga is slow set frameskip to 2 or more (using X128Prefs) to speed
  things up. After having started the emulator, press F7 to select the
  .TAP iimage and then select "Tape loader". The menu will load, press
  a number to select a game. F4 lets you select joystick type for
  those games that support a joystick. F10 exits the emulation.
