Sinclair ZX-81


The games are stored as .p files, whatever those are.


Windows

  The recommended emulator is No$zx81,

    http://www.work.de/nocash/zx8.htm

  Unpack it to a directory and start NO$ZX8.EXE. Select File ->
  Cassette menu (directory) in the menu. Doubleclick on a .p to start
  the game.


Unix

  Try Z81,

    http://rus.members.beeb.net/z81.html


MacOS

  Try ZX81,

    http://emulation.net/sinclair/


Amiga

  The recommended emulator is Z81,

    http://www.lagernet.clara.co.uk/8bitemu.html

  Start the emulator from CLI/Shell, with the following command:

    xz81 FILENAME.P

  Where FILENAME.P is the name of the game you want to play. If that
  doesn`t work, try the following instead:

    xz81 -w FILENAME.P

  This opens the emulator in a workbench window.
