Commodore C128


All the games are in a single D64 disk image. Most games requires a
joystick plugged into port 2.


Windows

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack it to a directory and start x128.exe. Select File ->
  Autostart disk/tape image... in the menu. Select the D64 image, then
  doubleclick on a game to start it. If joystick emulation isn't
  enabled by default, enable it in Settings -> Joystick settings.


Unix

  The recommended emulator is VICE,

    http://viceteam.bei.t-online.de/

  Unpack and compile with ./configure && make install, then start
  x128. Select File -> Autostart disk/tape image... in the menu.
  Select the D64 image, then doubleclick on a game to start it. If
  joystick emulation isn't enabled by default, enable it in Settings
  -> Joystick settings.


MacOS/Amiga

  I don't know of any emulators for these platforms.

