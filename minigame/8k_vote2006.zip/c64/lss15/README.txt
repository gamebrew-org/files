LSS 1.5:
8KB minigame
by Stefano Tognon
(C) 2006 Ice Team
version 1.00

Well, this game is dedicated to "little-ketty"
This is my 12th game for C64

Music created and composed by Richard Bayliss

CONCEPT:
An entension of (released) LSS1 and a minor version of (unreleaded) LSS2 game (based onto Giana sister type)

BACKGROUND:
This game was not planned, as I'm concentrated to LSS2 game. But as LSS2 engine have a fine running...

INSTRUCTIONS:
Put Joystick in port 2

Movement:
 LEFT:       goes left
 RIGHT:      goes right
 UP:         jump


Collect all the diamonds for having extra lifes and points. Kill all the enemies, but not the slowed ones!!
There are 9 levels to pass for winning


TECNIQUES:
* Use (cutted down) LSS2 engine
* Chars and levels were created using my LSS2 map editor.


OPTIMIZATIONS:
Removing some part of LSS2 engine (like boss enemy)


HUMOR:
At some point, the little-little boy say to little-ketty:
"mum, this game is too difficult to me, I'm not able to pass some screens 
 as enemy come out in an unexpected way"
and little-ketty says:
"hei, ice00 is a nice boy: he added a secret features in the game that 
 let you play it in another way..."
"wow, how can I activate it?"
"eh,eh, it is the case that you look at the source of the game, otherwise, just
try and try and try....to find it"

THANKS:
Thanks to all the authors of tools I used to make this game:
Vice, Exomizer, Dasm.


NOTE:
As this game is based onto LSS2, remember that there are lot of people that contributed to the game:
Luca, Ian Coog, Roberto, Dustbin, ecc..
Look at the LSS2 credits for more details

http://ready64.altervista.org/forum/index.php?showtopic=1647&st=60

Look for all the Ice Team release (always with source) at:
http://digilander.iol.it/ice00
